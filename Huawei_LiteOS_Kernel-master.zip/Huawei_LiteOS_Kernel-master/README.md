##Huawei LiteOS Kernel项目地址迁移至：https://github.com/LITEOS/LiteOS_Kernel.git
